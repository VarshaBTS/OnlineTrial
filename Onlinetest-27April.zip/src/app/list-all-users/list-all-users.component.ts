import { Component, OnInit } from '@angular/core';
import { Userdata, MyserviceService } from '../myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-all-users',
  templateUrl: './list-all-users.component.html',
  styleUrls: ['./list-all-users.component.css']
})
export class ListAllUsersComponent implements OnInit {

  message: string;
  employees: Userdata[];
  constructor(private myservice: MyserviceService, private router: Router) {
  }

  ngOnInit(): any {
    this.myservice.getUsers().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.employees = response;
  }
  update(updateemployee: Userdata) {
    this.myservice.update(updateemployee);
    this.router.navigate(['/updateUser']); //updating the employee
  }
  delete(deleteemployee: Userdata): any {
    this.myservice.delete(deleteemployee.userId).subscribe(data => {
      this.message = data
    });
   // this.router.navigate(['/listemp']);
  }
}
