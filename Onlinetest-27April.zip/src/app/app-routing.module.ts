import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ListAllUsersComponent } from './list-all-users/list-all-users.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { LogoutComponent } from './logout/logout.component';
import { ListtAllQuestionsComponent } from './listt-all-questions/listt-all-questions.component';
import { AddQuestionComponent } from './add-question/add-question.component';
import { UpdateQuestionComponent } from './update-question/update-question.component';


const routes: Routes = [
  {path:'signup',component:SignupComponent},
  {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent},
  {path:'listUser',component:ListAllUsersComponent},
  {path:'updateUser',component:UpdateUserComponent},
  {path:'logout',component:LogoutComponent},
  {path:'listQuestions',component:ListtAllQuestionsComponent},
  {path:'addQuestion',component:AddQuestionComponent},
  {path:'updateQuestion',component:UpdateQuestionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
